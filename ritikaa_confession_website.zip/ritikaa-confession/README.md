# For Ritikaa 💗

A cute, responsive, interactive confession website made with plain HTML, CSS and JavaScript.

## Preview locally
1. Download and unzip the project.
2. Open `index.html` in Chrome, Edge, or Firefox.
3. Click the music button if you want to hear the optional gentle synthesized chimes.

## Personalize before publishing
- Edit `index.html` in VS Code or Notepad.
- Change the text in the message, reasons, and memory cards so it sounds like you.
- Replace the placeholder memory captions with real, appropriate memories or inside jokes.
- You can change colours in the `:root` CSS variables near the top.

## Publish free with GitHub Pages
1. Sign in at https://github.com/
2. Click **New repository**.
3. Name it `ritikaa-confession` (or any name you prefer).
4. Set it to **Public**, then create the repository.
5. In the repository, click **Add file → Upload files**.
6. Upload `index.html` (and this README if you want). Make sure `index.html` is in the repository root, not inside another folder.
7. Click **Commit changes**.
8. Open **Settings → Pages**.
9. Under **Build and deployment**, choose **Deploy from a branch**.
10. Select branch **main** and folder **/(root)**, then click **Save**.
11. Wait a minute or two. The Pages section will show your site URL, usually:
   `https://YOUR-USERNAME.github.io/ritikaa-confession/`

If the page does not appear, check that the file is named exactly `index.html`, that it is in the root, and that Pages is set to `main` / `/(root)`.

## Notes
- No framework, build step, paid hosting, or external assets are required.
- The music button creates gentle chimes in the browser and starts only after a user click.
- The playful button grows when “Not sure” is clicked, but the recipient can still choose either answer.
